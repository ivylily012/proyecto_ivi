<?php
    $footer_sections = [
        'Conócenos' => [
            ['text' => 'Directorio de oficios', 'url' => '../HTML/directorio de oficios.html'],
            ['text' => 'Sobre Nosotros', 'url' => '../HTML/sobreNosotros.html'],
            ['text' => 'Contactanos', 'url' => '../HTML/contactanos.html']
        ],
        'Sobre Nosotros' => [
            ['text' => 'Nuestra Misión', 'url' => '../HTML/sobreNosotros.html'],
            ['text' => 'Nuestra Historia', 'url' => '../HTML/sobreNosotros.html'],
            ['text' => 'Como funciona', 'url' => '../HTML/sobreNosotros.html']
        ],
        // Puedes agregar más secciones aquí
    ];
?>